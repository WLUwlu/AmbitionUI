#coding=utf-8

def print_msg(*args):
    print(args)

t=[1,4]
#脱外套
print(t)
print(*t)
