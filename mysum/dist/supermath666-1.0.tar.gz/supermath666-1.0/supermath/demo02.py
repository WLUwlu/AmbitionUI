def multiple():
    print("multiple")